## qgo images

Images starting with *qgo* are tagen from [qgo] and are used under the following terms and conditions:

#### Copyright

Copyright (C) 2001-2006 Emmanuel Beranger, Johannes Mesa, Peter Strempel

This software is published under the GNU General Public License (GPL).
See the file COPYING for more informations or visit http://www.fsf.org/.


## sente images

Images starting with *sente* are taken from [Sente Goban] and are property of [Senten Sàrl]. They are (hopefully) reused with permission. The owner reserves all rights. Do not reuse them without explicit permission by [Senten Sàrl].

#### Copyright

Copyright © 1994-2017 Senten Sàrl. All rights reserved. Sente and Sen:te are protected trademarks of Senten Sàrl.


[qgo]: http://qgo.sourceforge.net/
[Senten Sàrl]: http://www.sente.ch/?lang=en
[Sente Goban]: http://www.gobanapp.com/
